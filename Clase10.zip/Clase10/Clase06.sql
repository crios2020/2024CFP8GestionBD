-- Active: 1723855658210@@127.0.0.1@3306@negocio
use negocio;

-- Objetos vista

/*
    Las vistas se crean a partir de una consulta select
*/
select * from clientes;

DROP VIEW IF EXISTS V_Clientes;
CREATE VIEW V_Clientes AS
    select id, CONCAT(nombre,' ',apellido) nombre, 
        CONCAT(tipo_doc,' ',numero_doc) documento, 
        fenaci fecha_de_nacimiento, TIMESTAMPDIFF(YEAR,fenaci,CURDATE()) edad,
        telefono, email, comentarios
        from clientes
        where activo=true;

SHOW TABLES;
select * from V_Clientes;
DESCRIBE V_Clientes;

-- Consulta de catalogos

-- Catalogo de tablas
SELECT TABLE_NAME 'tablas'  FROM information_schema.TABLES 
    WHERE TABLE_SCHEMA='negocio';

-- Cantidad total de tablas en el motor
SELECT COUNT(*) cantidad FROM information_schema.TABLES;

-- Catalogo de vistas
SELECT * FROM information_schema.VIEWS;

-- Catalogo de indices
SELECT i.NAME nombre_indice, t.NAME nombre_tabla 
        FROM information_schema.INNODB_SYS_INDEXES i
        JOIN  information_schema.INNODB_SYS_TABLES t 
        ON i.TABLE_ID=t.TABLE_ID
        WHERE t.NAME LIKE 'negocio/%';

-- Calcular la edad
SELECT fenaci,TIMESTAMPDIFF(YEAR,fenaci,CURDATE()) edad
     FROM clientes;

update clientes set fenaci="1973-02-02" where id=1;
update clientes set fenaci="2000-09-19" where id=2;
update clientes set fenaci="2000-09-20" where id=3;
update clientes set fenaci="2000-09-21" where id=4;
select 2024-1985;


select * from articulos;

/*
    Crear una vista de tabla articulos
    - debe agregar una columna con el precio final + iva
    - debe agregar una columna avisando si se debe reponer ese árticulo
        y otra columna con la cantidad de unidades a reponer,
        más otra columna con el costo de reposición 
*/

DESCRIBE articulos;

DROP VIEW IF EXISTS V_Articulos;
CREATE VIEW V_Articulos as
    select  id, 
        descripcion, 
        costo, 
        precio, 
        round(precio * 1.21,2) precio_final,
        stock, 
        stock_min, 
        stock_max,
        if(stock<=stock_min,'si','no') reponer_producto,
        if(stock<=stock_min,stock_max-stock,0) cantidad_a_reponer,
        if(stock<=stock_min,round((stock_max-stock)*costo,2),0) costo_de_reponer
        from articulos;

update articulos set stock=stock-68 where id=1;
select * from V_Articulos;

-- Objetos indices

-- Indice que permite valores duplicados
DROP INDEX IF EXISTS I_Clientes_Apellido ON clientes;
CREATE INDEX I_Clientes_Apellido
    ON clientes (apellido);


-- Indice que no permite valores duplicados
DROP INDEX IF EXISTS U_Clientes_Documento ON clientes;
CREATE UNIQUE INDEX U_Clientes_Documento 
    ON clientes (tipo_doc, numero_doc);
