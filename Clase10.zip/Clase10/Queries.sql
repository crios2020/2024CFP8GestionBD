use neg;

-- 1- Obtener el nombre completo y el número de documento de los clientes que tienen una factura
SELECT c.nombre, c.apellido, c.numero_doc
FROM clientes c
JOIN facturas f ON c.id = f.id_cliente
GROUP BY c.id;

-- 2- Listar los artículos que no han sido vendidos en ninguna factura
SELECT a.id, a.descripcion
FROM articulos a
LEFT JOIN detalles d ON a.id = d.id_articulo
WHERE d.id_factura IS NULL;

-- 3- Calcular el monto total facturado por cada cliente
SELECT c.nombre, c.apellido, SUM(f.monto) AS monto_total
FROM clientes c
JOIN facturas f ON c.id = f.id_cliente
GROUP BY c.id;

-- 4- Obtener los detalles de las facturas (número de factura, fecha, cliente, artículo, cantidad, valor unitario)
SELECT f.numero, f.fecha, c.nombre, c.apellido, a.descripcion, d.cantidad, d.valor_unidad
FROM facturas f
JOIN detalles d ON f.id = d.id_factura
JOIN clientes c ON f.id_cliente = c.id
JOIN articulos a ON d.id_articulo = a.id;

-- 5- Listar los 5 artículos más vendidos (descripción, cantidad total vendida)
SELECT a.descripcion, SUM(d.cantidad) AS total_vendido
FROM articulos a
JOIN detalles d ON a.id = d.id_articulo
GROUP BY a.id
ORDER BY total_vendido DESC
LIMIT 5;

-- 6- Obtener los clientes que no tienen ninguna factura registrada
SELECT c.nombre, c.apellido
FROM clientes c
LEFT JOIN facturas f ON c.id = f.id_cliente
WHERE f.id IS NULL;

-- 7- Calcular el valor del stock de cada artículo (descripción, stock, valor del stock)
SELECT a.descripcion, a.stock, a.stock * a.precio AS valor_stock
FROM articulos a;

-- 8- Obtener las facturas emitidas en el último mes, junto con los datos del cliente y los detalles de los artículos
SELECT f.id, f.numero, f.fecha, c.nombre, c.apellido, a.descripcion, d.cantidad, d.valor_unidad
FROM facturas f
JOIN clientes c ON f.id_cliente = c.id
JOIN detalles d ON f.id = d.id_factura
JOIN articulos a ON d.id_articulo = a.id
WHERE f.fecha >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH);

-- 9- Listar los clientes que han realizado compras por un monto mayor a $10,000
SELECT c.nombre, c.apellido, SUM(f.monto) AS monto_total
FROM clientes c
JOIN facturas f ON c.id = f.id_cliente
GROUP BY c.id
HAVING monto_total > 10000;

-- 10- Obtener un reporte de las facturas, indicando la cantidad de artículos, el monto total y el promedio de valor unitario por factura
SELECT f.id, f.numero, f.fecha, f.monto, COUNT(d.id) AS cantidad_articulos, AVG(d.valor_unidad) AS promedio_valor_unitario
FROM facturas f
JOIN detalles d ON f.id = d.id_factura
GROUP BY f.id;