use negocio;
-- Consulta de catalogos

-- Catalogo de tablas
SELECT TABLE_NAME 'tablas'  FROM information_schema.TABLES 
    WHERE TABLE_SCHEMA='negocio';

-- Catalogo de vistas
SELECT * FROM information_schema.VIEWS;

-- Catalogo de indices
SELECT i.NAME nombre_indice, t.NAME nombre_tabla 
        FROM information_schema.INNODB_SYS_INDEXES i
        JOIN  information_schema.INNODB_SYS_TABLES t 
        ON i.TABLE_ID=t.TABLE_ID
        WHERE t.NAME LIKE 'negocio/%';

-- Catalogo de constraint (restricción)
SELECT 
    CONSTRAINT_SCHEMA, TABLE_NAME, CONSTRAINT_NAME, CONSTRAINT_TYPE 
    FROM information_schema.TABLE_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA='negocio';

-- Catalogo de stored procedure (Procedimientos almacenador)
SELECT SPECIFIC_NAME, ROUTINE_SCHEMA, ROUTINE_TYPE FROM information_schema.ROUTINES 
            where ROUTINE_SCHEMA='negocio';


select VERSION(); 