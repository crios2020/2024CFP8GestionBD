package ar.org.centro8.curso.java;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import ar.org.centro8.curso.java.connector.Connector;

@SpringBootTest
public class TestTablaCliente {
    private Connection conn=Connector.getConnection();
    @Test
    public void registroValido(){
        try {
            ResultSet rs=conn
                .createStatement()
                .executeQuery("select max(id) from clientes");
            if(rs.next()){
                int lastId=rs.getInt(1);
                rs.close();
                String query=
                "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)";
                PreparedStatement ps= conn.prepareStatement(
                                query, 
                                PreparedStatement.RETURN_GENERATED_KEYS);
                ps.setString(1, "Juan");
                ps.setString(2,"Perez");
                ps.setString(3,"DNI");
                String nroRandom=((int)(Math.random()*99999999))+"";
                ps.setString(4, nroRandom);
                ps.setString(5,"1990-05-10");
                ps.execute();
                ResultSet rs2=ps.getGeneratedKeys();
                rs2.close();
                if(rs2.next()){
                    int newId=rs2.getInt(1);
                    assertEquals(lastId<newId, true);
                }else{
                    assertEquals(true, false);  
                }
            }else{
                assertEquals(true, false);
            }
            
        } catch (Exception e) {
            assertEquals(true, false);    
        }
    }
        
    @Test
    public void TestPrimaryKey(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (id,nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?,?)")) {
            ps.setInt(1, 1);
            ps.setString(2, "Roxana");
            ps.setString(3,"Juarez");
            ps.setString(4,"DNI");
            String nroRandom=((int)(Math.random()*99999999))+"";
            ps.setString(5, nroRandom);
            ps.setString(6,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    //realizar una prueba de unicidad en documento
    @Test
    public void TestUniqueKeyDocumento(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)")) {
            ps.setString(1, "Roxana");
            ps.setString(2,"Juarez");
            ps.setString(3,"DNI");
            ps.setString(4, "12345678");
            ps.setString(5,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    @Test
    public void TestLongitudNroDocumento1(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)")) {
            ps.setString(1, "Roxana");
            ps.setString(2,"Juarez");
            ps.setString(3,"DNI");
            String nroRandom=((int)(Math.random()*999999999))+"88";
            ps.setString(4, nroRandom);
            ps.setString(5,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    @Test
    public void TestLongitudNroDocumento2(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)")) {
            ps.setString(1, "Roxana");
            ps.setString(2,"Juarez");
            ps.setString(3,"DNI");
            String nroRandom=((int)(Math.random()*9999))+"";
            ps.setString(4, nroRandom);
            ps.setString(5,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    //realizar pruebas de longitud de nombre y apellidos
    @Test
    public void TestLongitudNombre1(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)")) {
            ps.setString(1, "Ro");
            ps.setString(2,"Juarez");
            ps.setString(3,"DNI");
            String nroRandom=((int)(Math.random()*99999999))+"";
            ps.setString(4, nroRandom);
            ps.setString(5,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    @Test
    public void TestLongitudNombre2(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)")) {
            ps.setString(1, "Roxana Roxana Roxana Roxana ");
            ps.setString(2,"Juarez");
            ps.setString(3,"DNI");
            String nroRandom=((int)(Math.random()*99999999))+"";
            ps.setString(4, nroRandom);
            ps.setString(5,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    @Test
    public void TestLongitudApellido1(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)")) {
            ps.setString(1, "Roxana");
            ps.setString(2,"Ju");
            ps.setString(3,"DNI");
            String nroRandom=((int)(Math.random()*99999999))+"";
            ps.setString(4, nroRandom);
            ps.setString(5,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    @Test
    public void TestLongitudApellido2(){
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)")) {
            ps.setString(1, "Roxana");
            ps.setString(2,"Juarez Juarez Juarez Juarez ");
            ps.setString(3,"DNI");
            String nroRandom=((int)(Math.random()*99999999))+"";
            ps.setString(4, nroRandom);
            ps.setString(5,"1990-05-10");
            ps.execute();
            assertEquals(true, false);      //rojo
        } catch (SQLException e) {
            assertEquals(true, true );      //verde
        } catch (Exception e){
            assertEquals(true, false);      //rojo
        }
    }

    //Crear prueba unitaria para fenaci que no sea mayor a la fecha actual
    @Test
    public void testFENACIFechaActual(){
        try {
            ResultSet rs=conn
                .createStatement()
                .executeQuery("select max(id) from clientes");
            if(rs.next()){
                int lastId=rs.getInt(1);
                rs.close();
                String query=
                "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)";
                PreparedStatement ps= conn.prepareStatement(
                                query, 
                                PreparedStatement.RETURN_GENERATED_KEYS);
                ps.setString(1, "Juan");
                ps.setString(2,"Perez");
                ps.setString(3,"DNI");
                String nroRandom=((int)(Math.random()*99999999))+"";
                ps.setString(4, nroRandom);
                ps.setString(5,"2029-10-10");
                ps.execute();
                assertEquals(true, false);
            }else{
                assertEquals(true, true);
            }
            
        } catch (Exception e) {
            assertEquals(true, false);    
        }
    }

    //Crear prueba unitaria para fenaci que no permite el ingreso de menores 
    //de 18 años
    @Test
    public void testFENACIMEnor18(){
        try {
            ResultSet rs=conn
                .createStatement()
                .executeQuery("select max(id) from clientes");
            if(rs.next()){
                int lastId=rs.getInt(1);
                rs.close();
                String query=
                "insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values (?,?,?,?,?)";
                PreparedStatement ps= conn.prepareStatement(
                                query, 
                                PreparedStatement.RETURN_GENERATED_KEYS);
                ps.setString(1, "Juan");
                ps.setString(2,"Perez");
                ps.setString(3,"DNI");
                String nroRandom=((int)(Math.random()*99999999))+"";
                ps.setString(4, nroRandom);
                ps.setString(5,"2023-10-10");
                ps.execute();
                assertEquals(true, false);
            }else{
                assertEquals(true, true);
            }
            
        } catch (Exception e) {
            assertEquals(true, false);    
        }
    }


}
