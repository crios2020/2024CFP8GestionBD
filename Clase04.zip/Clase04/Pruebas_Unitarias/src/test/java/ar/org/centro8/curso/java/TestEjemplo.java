package ar.org.centro8.curso.java;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TestEjemplo {
    
    @Test
	public void Test1() {
        assertEquals(true, true);           //verde
	}

    @Test
	public void Test2() {
        //assertEquals(true, false);           //rojo
	}

    @Test
	public void Test3() {
        assertEquals(2+2, 4);           //verde
	}

    @Test
	public void Test4() {
        //assertEquals(2+2, 5);           //rojo
	}
}
