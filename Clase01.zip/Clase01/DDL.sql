DROP DATABASE IF EXISTS negocio;
CREATE DATABASE negocio;
USE negocio;

DROP TABLE IF EXISTS detalles;
DROP TABLE IF EXISTS facturas;
DROP TABLE IF EXISTS articulos;
DROP TABLE IF EXISTS clientes;

CREATE TABLE clientes(
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25) NOT NULL CHECK(LENGTH(nombre)>=3),
    apellido VARCHAR(25) NOT NULL CHECK(LENGTH(apellido)>=3),
    tipo_doc ENUM('DNI','LC','LE','PASS') NOT NULL DEFAULT 'DNI',
    numero_doc VARCHAR(10) NOT NULL CHECK(LENGTH(numero_doc)>=5),
    fenaci DATE NOT NULL,
    telefono VARCHAR(20),
    email VARCHAR(30),
    comentarios VARCHAR(250),
    activo BOOLEAN NOT NULL DEFAULT true
);