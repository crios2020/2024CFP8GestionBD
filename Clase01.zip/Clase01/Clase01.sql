-- Active: 1723855658210@@127.0.0.1@3306
SHOW DATABASES;

-- Comentarios de una sola linea
/* Bloque de comentarios */

SELECT VERSION() version;

/*
    DDL Data Definition Language    - Lenguaje de definición de datos.
    DML Data Manipulation Language  - Lenguaje de manipulación de datos.
    DCL Data Control Language       - Lenguaje de control de datos.
*/
